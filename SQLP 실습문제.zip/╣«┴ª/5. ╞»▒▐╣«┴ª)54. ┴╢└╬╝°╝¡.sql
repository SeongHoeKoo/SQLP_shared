/* ����)  ���� ������ ���� �Ʒ� OLTP��  SQL�� Ʃ���Ͻÿ�.
T_CUST54   : ��  10����
     CUST_NO    VARCHAR2(6)   <== PK
     CUST_NM    VARCHAR2(50)
     CUST_TYPE  VARCHAR2(4) 
     ��Ÿ �߰� Į�� ����
     
T_HOBBY54  : ��  30����
   CUST_NO    VARCHAR2(6)    <== PK
   HOBBY_TYPE VARCHAR2(1)    <== PK
   ��Ÿ �߰� Į�� ����
   
T_ORDER54  : �� 300����
   ORDER_NO   VARCHAR2(7)  <== PK
   CUST_NO    VARCHAR2(6)
   ORDER_DT   VARCHAR2(8)
   ORDER_TYPE VARCHAR2(3)
   ��Ÿ �߰� Į�� ����

CREATE INDEX YOON.IX_T_ORDER54_01 ON YOON.T_ORDER54(CUST_NO);
CREATE INDEX YOON.IX_T_CUST54_01 ON YOON.T_CUST54(CUST_TYPE);
*/
SELECT /*+ LEADING (C H O@T_ORDER54) USE_NL(H) */ C.CUST_NO, C.CUST_NM, H.HOBBY_TYPE, H.C11
FROM T_CUST54 C,  T_HOBBY54 H
WHERE C.CUST_TYPE    = 'C050'
  AND H.CUST_NO = C.CUST_NO
  AND EXISTS (SELECT /*+ QB_NAME(T_ORDER54) UNNEST */ 1
              FROM T_ORDER54 O
              WHERE CUST_NO    = C.CUST_NO
               AND  ORDER_TYPE = '001'
               AND  ORDER_DT IS NULL );
/*
------------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name            | Starts | A-Rows |   A-Time   | Buffers | Reads  |
------------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |                 |      1 |     18 |00:02:05.63 |   19497 |  16378 |
|*  1 |  FILTER                        |                 |      1 |     18 |00:02:05.63 |   19497 |  16378 |
|   2 |   NESTED LOOPS                 |                 |      1 |   1500 |00:00:13.52 |    3015 |   1502 |
|   3 |    NESTED LOOPS                |                 |      1 |   1500 |00:00:00.07 |    1515 |      3 |
|   4 |     TABLE ACCESS BY INDEX ROWID| T_CUST54        |      1 |    500 |00:00:00.05 |     505 |      3 |
|*  5 |      INDEX RANGE SCAN          | IX_T_CUST54_01  |      1 |    500 |00:00:00.01 |       5 |      0 |
|*  6 |     INDEX RANGE SCAN           | PK_HOBBY54      |    500 |   1500 |00:00:00.02 |    1010 |      0 |
|   7 |    TABLE ACCESS BY INDEX ROWID | T_HOBBY54       |   1500 |   1500 |00:00:13.45 |    1500 |   1499 |
|*  8 |   TABLE ACCESS BY INDEX ROWID  | T_ORDER54       |    500 |      6 |00:01:52.10 |   16482 |  14876 |
|*  9 |    INDEX RANGE SCAN            | IX_T_ORDER54_01 |    500 |  14945 |00:00:04.18 |    1537 |    319 |
------------------------------------------------------------------------------------------------------------
 
Predicate Information (identified by operation id):
--------------------------------------------------- 
   1 - filter( IS NOT NULL)
   5 - access("C"."CUST_TYPE"='C010')
   6 - access("H"."CUST_NO"="C"."CUST_NO")
   8 - filter(("ORDER_DT" IS NULL AND "ORDER_TYPE"='010'))
   9 - access("CUST_NO"=:B1)  */