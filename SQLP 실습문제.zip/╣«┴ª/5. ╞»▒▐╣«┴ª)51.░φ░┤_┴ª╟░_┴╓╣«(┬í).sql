--SQL
SELECT /*+ ORDERED USE_NL(P O) */
       P.PROD_NM, P.PROD_ID, O.ORDER_QTY
FROM   T_MANUF M, T_PRODUCT P,  T_ORDER O
WHERE  M.M_CODE BETWEEN 'M00001' AND 'M00100'
 AND   P.M_CODE  = M.M_CODE
 AND   O.PROD_ID = P.PROD_ID
 AND   O.ORDER_DT = '20160412'
 AND   O.ORDER_QTY > 9000;

-- Index ����
/*
CREATE UNIQUE INDEX YOON.PK_T_MANUF    ON YOON.T_MANUF  (M_CODE);
CREATE UNIQUE INDEX YOON.PK_T_PRODUCT  ON YOON.T_PRODUCT(M_CODE, PROD_ID);
CREATE        INDEX YOON.IX_T_ORDER_01 ON YOON.T_ORDER  (PROD_ID, ORDER_DT, ORDER_QTY);

Rows     Row Source Operation
-------  ---------------------------------------------------
     32  NESTED LOOPS  (cr=10148 pr=0 pw=0 time=27590 us cost=629 size=870 card=10)
  10000   NESTED LOOPS  (cr=10138 pr=0 pw=0 time=14682 us cost=108 size=7176 card=104)
    100    INDEX RANGE SCAN PK_T_MANUF (cr=3 pr=0 pw=0 time=99 us cost=2 size=6 card=1)(object id 73593)
  10000    TABLE ACCESS BY INDEX ROWID T_PRODUCT (cr=10135 pr=0 pw=0 time=12005 us cost=106 size=6552 card=104)
  10000     INDEX RANGE SCAN PK_T_PRODUCT (cr=135 pr=0 pw=0 time=1810 us cost=1 size=0 card=104)(object id 73595)
     32   INDEX RANGE SCAN IX_T_ORDER_01 (cr=10 pr=0 pw=0 time=0 us cost=5 size=18 card=1)(object id 73602)



����)
  �ε����� ���� ������ �Ұ����� �����̴�.  
  SQL�� Ʃ�� �Ͻÿ�. (�ε��� ���� ����)
  
*/