/*======================================================================
    ������ 1�� (2018.09.01)
    
���� SQL�� Ʃ���Ͻÿ�.
  - Ʃ�� �� ��Ʈ�� ���� ���� (��Ƽ�������� �˾Ƽ� ó���ϵ��� �� ��)
  - UNION ALL�� �ٸ� ����ȭ ����� ���� ��쿡�� ����ϵ��� �� ��
  - I/O�� �����̶� �پ��ٸ� INDEX �߰� ����
  - ��, ���ʿ��� INDEX�� ��� ������ ����
=======================================================================*/

ALTER SESSION SET WORKAREA_SIZE_POLICY='MANUAL';
ALTER SESSION SET SORT_AREA_SIZE=2000000000;

CREATE INDEX YOON.IX_T_TAB64_01 ON YOON.T_TAB64(PRCD, DT);
CREATE INDEX YOON.IX_T_TAB64_02 ON YOON.T_TAB64(CNO, PRCD, DT);
EXECUTE DBMS_STATS.GATHER_TABLE_STATS('YOON', 'T_TAB64');

ALTER SESSION SET WORKAREA_SIZE_POLICY='AUTO';

ALTER SESSION SET STATISTICS_LEVEL = ALL;

-------- �� ��� OR-Expasion�� �߻��Ͽ� CONTENATION���� �б��ϴ� ���
SELECT CNO, DT, SEQ, PRCD, ORDQ, ORDP, DCSSCD
      , (SELECT MAX(DT)
        FROM   T_TAB64
        WHERE  CNO  = O.CNO
         AND   PRCD = O.PRCD
         AND   DCSSCD IN ('D49997', 'D49930')
         AND   DT <= O.DT) PRVLAST
FROM T_TAB64 O
WHERE CNO = NVL(:CNO, CNO) 
 AND  O.DT BETWEEN  '20180203' AND '20180205'
 AND  O.PRCD IN ('P000003', 'P000045', 'P000070')
;

SELECT * FROM TABLE(DBMS_XPLAN.DISPLAY_CURSOR(NULL, NULL, 'IOSTATS LAST'));
/*
PLAN_TABLE_OUTPUT
----------------------------------------------------------------------------------------------------------
| Id  | Operation                      | Name          | Starts | E-Rows | A-Rows |   A-Time   | Buffers |
----------------------------------------------------------------------------------------------------------
|   0 | SELECT STATEMENT               |               |      1 |        |      3 |00:00:00.01 |       7 |
|   1 |  SORT AGGREGATE                |               |      3 |      1 |      3 |00:00:00.01 |      17 |
|*  2 |   TABLE ACCESS BY INDEX ROWID  | T_TAB64       |      3 |      1 |    105 |00:00:00.01 |      17 |
|*  3 |    INDEX RANGE SCAN            | IX_T_TAB64_02 |      3 |      1 |    105 |00:00:00.01 |      11 |
|   4 |  CONCATENATION                 |               |      1 |        |      3 |00:00:00.01 |       7 |
|*  5 |   FILTER                       |               |      1 |        |      0 |00:00:00.01 |       0 |
|   6 |    INLIST ITERATOR             |               |      0 |        |      0 |00:00:00.01 |       0 |
|*  7 |     TABLE ACCESS BY INDEX ROWID| T_TAB64       |      0 |      1 |      0 |00:00:00.01 |       0 |
|*  8 |      INDEX RANGE SCAN          | IX_T_TAB64_01 |      0 |     93 |      0 |00:00:00.01 |       0 |
|*  9 |   FILTER                       |               |      1 |        |      3 |00:00:00.01 |       7 |
|  10 |    TABLE ACCESS BY INDEX ROWID | T_TAB64       |      1 |      1 |      3 |00:00:00.01 |       7 |
|* 11 |     INDEX RANGE SCAN           | PKT_T_64      |      1 |      1 |      3 |00:00:00.01 |       5 |
----------------------------------------------------------------------------------------------------------
 
Predicate Information (identified by operation id):
---------------------------------------------------
 
   2 - filter(("DCSSCD"='D49930' OR "DCSSCD"='D49997'))
   3 - access("CNO"=:B1 AND "PRCD"=:B2 AND "DT"<=:B3)
   5 - filter(:CNO IS NULL)
   7 - filter("CNO"=TO_NUMBER(TO_CHAR("CNO")))
   8 - access((("O"."PRCD"='P000003' OR "O"."PRCD"='P000045' OR "O"."PRCD"='P000070')) AND 
              "O"."DT">='20180203' AND "O"."DT"<='20180205')
   9 - filter(:CNO IS NOT NULL)
  11 - access("CNO"=TO_NUMBER(:CNO) AND "O"."DT">='20180203' AND "O"."DT"<='20180205')
       filter(("O"."PRCD"='P000003' OR "O"."PRCD"='P000045' OR "O"."PRCD"='P000070'))
 
*/
